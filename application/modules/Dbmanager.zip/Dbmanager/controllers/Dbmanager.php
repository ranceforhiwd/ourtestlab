<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dbmanager extends MX_Controller {
        
public $add = array();
    public $remove = array();
    public $modify = array();    
    public $dbupdates = array();
    public $currentDbSrc = 'voluntee_testdb';
    
    public function __construct(){
            parent::__construct();
            $this->load->helper(array('url', 'html'));
            $this->load->library('session');
            $this->load->database();
            $this->load->model('dbmanager_model');
    }

    public function index(){       
        if(isset($_POST['process']) && $_POST['process'] == 'upgrade'){
            $_SESSION['updgrade'] = 1;
        }else{
            $_SESSION['updgrade'] = 0;
        }
            $this->load->view('dbmanager_view2');
    }
    
    /*public function testfile(){
        $this->dbmanager_model->test_file();
    }*/

    public function getTableNames(){
        $this->load->model('dbmanager_model');
        $names = $this->dbmanager_model->get_table_names($_POST['database']);
        exit(json_encode($names));
    }
    
    public function getViewNames(){
        $this->load->model('dbmanager_model');
        $names = $this->dbmanager_model->get_view_names($_POST['database']);
        exit(json_encode($names));
    }
    
    public function getColumnNames(){
        $this->load->model('dbmanager_model');
        $names = $this->dbmanager_model->get_column_names();
        exit(json_encode($names));
    }
    
    public function getTableCount(){
        $this->load->model('dbmanager_model');
        $count = $this->dbmanager_model->get_table_count();
        exit(json_encode($count));
    }
    
    public function getViewCount(){
        $this->load->model('dbmanager_model');
        $count = $this->dbmanager_model->get_view_count();
        exit(json_encode($count));
    }
    
    public function getColumnKeys(){
        $this->load->model('dbmanager_model');
        $ck = $this->dbmanager_model->get_column_keys();
        exit(json_encode($ck));
    }
    
    public function getTableKeys(){
        $this->load->model('dbmanager_model');
        $tk = $this->dbmanager_model->get_table_keys();
        exit(json_encode($tk));
    }
    
    public function getViewDetails(){
        $this->load->model('dbmanager_model');
        $vdet = $this->dbmanager_model->get_view_details();
        exit(json_encode($vdet));
    }
    
    public function certifyDb(){
        $this->load->model('dbmanager_model');
        $cd = $this->dbmanager_model->certify_db($_POST['database']);
        exit(json_encode($cd));
    }
    
    public function getAllDbConfig(){        
        $this->load->model('dbmanager_model');
        $adbc = $this->dbmanager_model->get_all_db_config();
        exit(json_encode($adbc));
    }
            
    public function getBaseDbConfig(){
        $this->load->model('dbmanager_model');
        $bdbc = $this->dbmanager_model->get_base_db_config();
        exit(json_encode($bdbc));
    }
    
    public function updateDbRecord(){
        $this->load->model('dbmanager_model');        
        $this->dbmanager_model->update_db_record();     
        $updated_record_status = $this->dbmanager_model->create_db_file(str_replace("'","^",serialize($this->dbmanager_model->get_base_db_config())));
        exit(json_encode('updated_record_status'));
    }
    
    public function getDbNames(){
        $this->load->model('dbmanager_model');
        $dbnames = $this->dbmanager_model->get_db_names();        
        exit(json_encode($dbnames));
    }
    
    public function compareDb(){
        $table_diff = array();
        $s1 = array();
        $t1 = array();
        $skeys = array('source'=>'');
        $tkeys = array('target'=>'');
        $this->load->model('dbmanager_model');
        $_SESSION['dbname'] = $_POST['dbname'];
        //Compare table names
        $target_table_names = $this->dbmanager_model->get_listof_tables($_POST['dbname']);
        $source_table_names = $this->dbmanager_model->get_listof_tables($this->currentDbSrc);        
        $table_diff['add'] = array_diff($source_table_names, $target_table_names);
        $table_diff['remove'] = array_diff($target_table_names, $source_table_names);
        $this->add = $table_diff['add'];
        $this->remove = $table_diff['remove'];
        
        //Compare column names per table
        foreach ($target_table_names as $tn1) {
            if(!in_array($tn1, $table_diff['remove'])){
                $t1[] = $tn1;
            }          
        }
        
        foreach ($source_table_names as $tn2) {
            if(!in_array($tn2, $table_diff['add'])){
                $s1[] = $tn2;
            }
        }                        
        
        //Add or remove columns
        $table_diff['modifyAdd'][] = $this->compareColsToAdd($_POST['dbname'], $s1, $t1);
        $table_diff['modifyRemove'][] = $this->compareColsToRemove($_POST['dbname'], $s1, $t1); 
       
        //Compare column data types
        $table_diff['dataTypes'] = $this->dbmanager_model->compare_data_types($_POST['dbname'], $s1, $t1);      
        
        //Compare indexes per table        
        foreach ($s1 as $source_table) {
            $skeys['source'][$source_table] = $this->dbmanager_model->get_keys_per_table($this->currentDbSrc.'.'.$source_table);
        }
        
        foreach ($t1 as $target_table) {
            $tkeys['target'][$target_table] = $this->dbmanager_model->get_keys_per_table($_POST['dbname'].'.'.$target_table);
        }
        
        if(isset($skeys['source']) && isset($tkeys['target']) && !empty($skeys['source']) && !empty($tkeys['target'])){
            $table_diff['keystoupdate'] = array_keys($this->dbmanager_model->arrayRecursiveDiff($skeys['source'], $tkeys['target']));   
        }else{
            $table_diff['keystoupdate'] = '';
        }
        
        //Compare collations
        
        //Store current database differences in session array
        $_SESSION['db_diff'] = $table_diff;
        $table_diff['dbname'] = $_POST['dbname'];  
        exit(json_encode($table_diff));
    }
    
    public function compareColsToAdd($database, $s, $t){
        $source = array();
        $target = array();
        
        foreach ($s as $stable){
            $source[$stable] = $this->dbmanager_model->get_table_column_names($this->currentDbSrc, $stable);
        }
        
        foreach ($t as $ttable){
            $target[$ttable] = $this->dbmanager_model->get_table_column_names($database, $ttable);
        }                       
        
        $column_diff = $this->dbmanager_model->arrayRecursiveDiff($source, $target);      
        $final_diff = $this->dbmanager_model->compare_columns($column_diff, $source, $target);
        
        return $final_diff;
    }
    
    public function compareColsToRemove($database, $s, $t){
        $source = array();
        $target = array();
        
        foreach ($s as $stable){
            $source[$stable] = $this->dbmanager_model->get_table_column_names($this->currentDbSrc, $stable);
        }
        
        foreach ($t as $ttable){
            $target[$ttable] = $this->dbmanager_model->get_table_column_names($database, $ttable);
        }                       
        
        $column_diff = $this->dbmanager_model->arrayRecursiveDiff($target, $source);        
        $final_diff = $this->dbmanager_model->compare_columns_to_remove($column_diff, $source, $target);
        
        return $final_diff;
    }
    
    public function addTables(){
        $_SESSION['update_results'] = array();
        $this->load->model('dbmanager_model');
        $base_db = $_SESSION['base_db_obj'];        
        $current_db_diff = $_SESSION['db_diff'];
        $tables_added = array();
        
        foreach ($current_db_diff['add'] as $tableToAdd) {
            if(isset($base_db['table_names']['tables'][$tableToAdd])){            
                $tables_added[] = $this->dbmanager_model->add_new_table($base_db['table_names']['tables'][$tableToAdd]);
            }            
        }
        
        $_SESSION['update_results']['tables_added'] = $tables_added;
        
        exit(json_encode($_SESSION['db_diff']));
    }
    
    public function removeTables(){
        $tables_renamed = array();
        
        if(isset($_POST['removelist']) && !empty($_POST['removelist'])){
            foreach ($_POST['removelist'] as $tableToRemove) {            
                $tables_renamed[] = $this->dbmanager_model->rename_table($tableToRemove);
            }
        }        
        
        $_SESSION['update_results']['tables_renamed'] = $tables_renamed;
        
        exit(json_encode($_SESSION['db_diff']));
    }
    
    public function removeColumns(){
        $columns_dropped = array();
        
        if(isset($_POST['removecols'])){
            $tc1 = $_POST['removecols'];
            $tc2 = array_shift($tc1);

            foreach ($tc2 as $tablename => $colarray) {
                foreach ($colarray as $colToRemove) {
                    $columns_dropped[] = $this->dbmanager_model->remove_columns($tablename, $colToRemove);
                }            
            }
        }
        
        $_SESSION['update_results']['columns_dropped'] = $columns_dropped;
        
        exit(json_encode($_SESSION['db_diff']));
    }
    
    public function modifyColumns(){
        $this->load->model('dbmanager_model');
        $columns_modified = array();
        
        if(isset($_POST['modify']) && !empty($_POST['modify'])){                  
            $columns_to_modify = $_SESSION['db_diff']['dataTypes'];
                                 
            foreach ($columns_to_modify as $key => $value) {
                $i[$key] = array_shift($value);
            }
            
            foreach ($i as $tablename => $colsArray) {
                if(isset($colsArray) && !empty($colsArray)){
                    foreach ($colsArray as $colname => $valueArray) {                        
                        $columns_modified[] = $this->dbmanager_model->modify_column($tablename, $colname, $valueArray, $_SESSION['base_db_obj']['table_names']['tables'][$tablename]['columns'][$colname]);
                    }
                }                                         
            }
        }
        
        $_SESSION['update_results']['columns_modified'] = $columns_modified;
                        
        exit(json_encode($_SESSION['db_diff']));
    }
    
    public function addColumns(){
        $columns_added = array();
        
        if(isset($_POST['modifyAdd']) && !empty($_POST['modifyAdd'])){
            $this->load->model('dbmanager_model');       
            $columns_to_add = array_shift($_POST['modifyAdd']);

            foreach ($columns_to_add as $tablename => $columnList) {
                $columns_added[] = $this->dbmanager_model->add_column($tablename, $columnList, $_SESSION['base_db_obj']);
            }
        }
        
        $_SESSION['update_results']['columns_added'] = $columns_added;
                        
        exit(json_encode($_SESSION['db_diff']));
    }
    
    public function updateIndexes(){
        $indexes_updated = array();
        
        $this->load->model('dbmanager_model');
        if(isset($_POST['tablelist']) && !empty($_POST['tablelist'])){
            $tables_to_update = $_POST['tablelist'];
            
            foreach ($tables_to_update as $table_name) {
                if($table_name != 'piwik_visits'){                
                    //Drop indexes
                    $indexes_updated['dropped'][] = $this->dbmanager_model->drop_indexes($table_name, $_SESSION['base_db_obj']['table_names']['tables'][$table_name]['keys']);
                    //Add indexes
                    $indexes_updated['added'][] = $this->dbmanager_model->add_indexes($table_name, $_SESSION['base_db_obj']['table_names']['tables'][$table_name]['keys']);
                }            
            }
        }
        
        $_SESSION['update_results']['updated_indexes'] = $indexes_updated;
                        
        $_SESSION['update_results']['updated_auto_increments'] = $this->dbmanager_model->update_ai($_SESSION['primary_keys']);
        
        exit(json_encode($_SESSION['update_results']));
    }
    
    public function updateViews(){
        $this->load->model('dbmanager_model');
        $source_view_list = array_keys($_SESSION['base_db_obj']['view_names']);
                      
        foreach ($source_view_list as $view_name){
            if($view_name != 'view_count'){
                $view_dep_obj = $this->dbmanager_model->lookup_view_dep($view_name, $_POST['dbname']);                
                if($view_dep_obj['vcount'] > 0 && isset($view_dep_obj['dep']['views'])){                    
                    $this->dbmanager_model->lookup_view_dep($view_dep_obj['dep']['views'][0], $_POST['dbname']);
                }
            }               
        }

        //compare final view totals
        $missing_view_list = $this->dbmanager_model->compare_views($_SESSION['dbname'], $source_view_list);
                
        exit(json_encode($missing_view_list));      
    }
    
    public function getAuditLog(){
        exit(json_encode($this->dbmanager_model->get_audit()));
    }
    
    public function clearAuditSessionData(){
        $this->dbmanager_model->reset_session_data();
    }
         
}
?>
